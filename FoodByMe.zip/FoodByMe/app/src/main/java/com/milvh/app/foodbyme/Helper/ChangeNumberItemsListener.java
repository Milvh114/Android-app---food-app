package com.milvh.app.foodbyme.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
